  <div role="tabpanel" id="tab-savings_ending" class="tab-pane">
      <span data-bind="text:month_names.month1"></span>
        <div class="panel-body"><br>
            <center ><h3>Savings Account - Monthly Ending Balances</h3></center>
            <br>
            <div class="row d-flex flex-row-reverse mx-2 my-2">
            <a target="_blank" id="btn_print_month_ending_bal">
              <button class="btn btn-primary btn-sm">
                <i class="fa fa-file-excel-o fa-2x"></i>
              </button>
            </a>
          </div>
        <div class="row">
            <div class="col-lg-12">
            <div class="table-responsive">
                 <table class="table table-bordered display compact nowrap table-hover"  width="100%" id="tblSavings_ending">    
                 </table>
             </div>
            </div>
          </div>
        </div>
  </div>
               